<?php
    header('location: view/landingpage.html');
?>
